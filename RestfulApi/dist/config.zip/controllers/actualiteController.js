var models = require('../models');
var jwt = require('jsonwebtoken');
var auth = require('../config/auth');