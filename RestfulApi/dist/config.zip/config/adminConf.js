module.exports = {
    login: "admin",
    password: "p@$$w0Rd",
    email: "admin@admin.admin"
}